
import React from 'react';
import { User, Briefcase, Zap, Mail, MessageSquare, Gamepad2, Award, Users, Star, Code2, Globe } from 'lucide-react';
import { AppType, Project, Skill } from './types';

export const APPS = [
  { id: AppType.ABOUT, name: 'About', icon: <User className="w-8 h-8 text-white" />, color: 'bg-blue-500' },
  { id: AppType.PROJECTS, name: 'Projects', icon: <Briefcase className="w-8 h-8 text-white" />, color: 'bg-green-500' },
  { id: AppType.SKILLS, name: 'Skills', icon: <Zap className="w-8 h-8 text-white" />, color: 'bg-orange-500' },
  { id: AppType.GEMINI, name: 'AI Ask', icon: <MessageSquare className="w-8 h-8 text-white" />, color: 'bg-purple-600' },
  { id: AppType.GAME, name: 'iRunner', icon: <Gamepad2 className="w-8 h-8 text-white" />, color: 'bg-yellow-500' },
  { id: AppType.CONTACT, name: 'Contact', icon: <Mail className="w-8 h-8 text-white" />, color: 'bg-red-500' },
];

export const PROJECTS_DATA: Project[] = [
  {
    id: '1',
    title: 'FinTrack Pro',
    description: 'A comprehensive wealth management suite featuring predictive AI spending insights, real-time crypto tracking, and bank-grade encryption for over 500k active users.',
    tech: ['React Native', 'TypeScript', 'Node.js', 'PostgreSQL', 'AWS'],
    image: 'https://images.unsplash.com/photo-1551288049-bbda38a5f971?auto=format&fit=crop&q=80&w=800&h=400'
  },
  {
    id: '2',
    title: 'HealthFlow Wear',
    description: 'An ecosystem for health monitoring. Integrates deeply with Apple HealthKit and Google Fit to provide biometric feedback and personalized workout regimes using CoreML.',
    tech: ['SwiftUI', 'Combine', 'HealthKit', 'Core ML', 'Firebase'],
    image: 'https://images.unsplash.com/photo-1510017803434-a899398421b3?auto=format&fit=crop&q=80&w=800&h=400'
  },
  {
    id: '3',
    title: 'EcoMarket 2.0',
    description: 'The world\'s first decentralized marketplace for verified carbon credits. Built to facilitate transparent green trading between SMEs and environmental projects.',
    tech: ['Flutter', 'Dart', 'Solidity', 'Web3.js', 'IPFS'],
    image: 'https://images.unsplash.com/photo-1542601906990-b4d3fb778b09?auto=format&fit=crop&q=80&w=800&h=400'
  }
];

export const EXPERIENCE_DATA = [
  {
    company: 'TechFlow Solutions',
    role: 'Lead Mobile Architect',
    period: '2022 - Present',
    description: 'Leading a team of 12 developers in rebuilding the core mobile infrastructure. Improved app startup time by 40% and implemented a company-wide design system.'
  },
  {
    company: 'AppVerse Studios',
    role: 'Senior Mobile Engineer',
    period: '2020 - 2022',
    description: 'Architected multiple high-traffic consumer apps. Specialized in React Native performance optimization and complex animations.'
  },
  {
    company: 'PixelPoint Creative',
    role: 'iOS Developer',
    period: '2018 - 2020',
    description: 'Developed and maintained 5+ native iOS applications. Focused on UI/UX excellence and seamless backend integration.'
  }
];

export const ACHIEVEMENTS_DATA = [
  { label: 'App Store Rating', value: '4.9/5', icon: <Star className="w-6 h-6 text-yellow-500" /> },
  { label: 'Happy Users', value: '2M+', icon: <Users className="w-6 h-6 text-blue-500" /> },
  { label: 'Awards Won', value: '12', icon: <Award className="w-6 h-6 text-purple-500" /> },
  { label: 'Lines of Code', value: '1M+', icon: <Code2 className="w-6 h-6 text-green-500" /> }
];

export const SKILLS_DATA: Skill[] = [
  { name: 'React Native', level: 95 },
  { name: 'Swift/SwiftUI', level: 92 },
  { name: 'Kotlin/Android', level: 85 },
  { name: 'TypeScript', level: 90 },
  { name: 'Flutter', level: 82 },
  { name: 'Three.js', level: 78 }
];
